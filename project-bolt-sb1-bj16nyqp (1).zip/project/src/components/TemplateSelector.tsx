import React from 'react';
import { TemplateType } from '../types';
import { Layout, Columns, AlignLeft } from 'lucide-react';

interface TemplateSelectorProps {
  selectedTemplate: TemplateType;
  onSelect: (template: TemplateType) => void;
}

export const TemplateSelector: React.FC<TemplateSelectorProps> = ({
  selectedTemplate,
  onSelect,
}) => {
  const templates: { type: TemplateType; name: string; icon: React.ReactNode }[] = [
    { type: 'modern', name: 'Modern', icon: <Layout size={24} /> },
    { type: 'classic', name: 'Classic', icon: <AlignLeft size={24} /> },
    { type: 'minimal', name: 'Minimal', icon: <Columns size={24} /> },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      {templates.map(({ type, name, icon }) => (
        <button
          key={type}
          onClick={() => onSelect(type)}
          className={`p-6 rounded-lg border-2 transition-all ${
            selectedTemplate === type
              ? 'border-blue-500 bg-blue-50'
              : 'border-gray-200 hover:border-blue-200'
          }`}
        >
          <div className="flex flex-col items-center gap-3">
            <div
              className={`${
                selectedTemplate === type ? 'text-blue-500' : 'text-gray-600'
              }`}
            >
              {icon}
            </div>
            <span
              className={`font-medium ${
                selectedTemplate === type ? 'text-blue-700' : 'text-gray-700'
              }`}
            >
              {name}
            </span>
          </div>
        </button>
      ))}
    </div>
  );
};