import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { ResumeData } from '../types';

interface ResumeFormProps {
  data: ResumeData;
  onChange: (data: ResumeData) => void;
}

export const ResumeForm: React.FC<ResumeFormProps> = ({ data, onChange }) => {
  const addExperience = () => {
    onChange({
      ...data,
      experience: [
        ...data.experience,
        {
          id: Date.now().toString(),
          company: '',
          position: '',
          startDate: '',
          endDate: '',
          highlights: [''],
        },
      ],
    });
  };

  const addEducation = () => {
    onChange({
      ...data,
      education: [
        ...data.education,
        {
          id: Date.now().toString(),
          institution: '',
          degree: '',
          field: '',
          graduationDate: '',
        },
      ],
    });
  };

  return (
    <div className="space-y-6 p-6 bg-white rounded-lg shadow">
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Personal Information</h2>
        <div className="grid grid-cols-2 gap-4">
          <input
            type="text"
            placeholder="Full Name"
            className="p-2 border rounded"
            value={data.personalInfo.name}
            onChange={(e) =>
              onChange({
                ...data,
                personalInfo: { ...data.personalInfo, name: e.target.value },
              })
            }
          />
          <input
            type="email"
            placeholder="Email"
            className="p-2 border rounded"
            value={data.personalInfo.email}
            onChange={(e) =>
              onChange({
                ...data,
                personalInfo: { ...data.personalInfo, email: e.target.value },
              })
            }
          />
          <input
            type="tel"
            placeholder="Phone"
            className="p-2 border rounded"
            value={data.personalInfo.phone}
            onChange={(e) =>
              onChange({
                ...data,
                personalInfo: { ...data.personalInfo, phone: e.target.value },
              })
            }
          />
          <input
            type="text"
            placeholder="Location"
            className="p-2 border rounded"
            value={data.personalInfo.location}
            onChange={(e) =>
              onChange({
                ...data,
                personalInfo: { ...data.personalInfo, location: e.target.value },
              })
            }
          />
        </div>
        <textarea
          placeholder="Professional Summary"
          className="w-full p-2 border rounded h-32"
          value={data.personalInfo.summary}
          onChange={(e) =>
            onChange({
              ...data,
              personalInfo: { ...data.personalInfo, summary: e.target.value },
            })
          }
        />
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Experience</h2>
          <button
            onClick={addExperience}
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            <Plus size={16} /> Add Experience
          </button>
        </div>
        {data.experience.map((exp, index) => (
          <div key={exp.id} className="space-y-4 p-4 border rounded">
            <div className="grid grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Company"
                className="p-2 border rounded"
                value={exp.company}
                onChange={(e) => {
                  const newExp = [...data.experience];
                  newExp[index] = { ...exp, company: e.target.value };
                  onChange({ ...data, experience: newExp });
                }}
              />
              <input
                type="text"
                placeholder="Position"
                className="p-2 border rounded"
                value={exp.position}
                onChange={(e) => {
                  const newExp = [...data.experience];
                  newExp[index] = { ...exp, position: e.target.value };
                  onChange({ ...data, experience: newExp });
                }}
              />
              <input
                type="text"
                placeholder="Start Date"
                className="p-2 border rounded"
                value={exp.startDate}
                onChange={(e) => {
                  const newExp = [...data.experience];
                  newExp[index] = { ...exp, startDate: e.target.value };
                  onChange({ ...data, experience: newExp });
                }}
              />
              <input
                type="text"
                placeholder="End Date"
                className="p-2 border rounded"
                value={exp.endDate}
                onChange={(e) => {
                  const newExp = [...data.experience];
                  newExp[index] = { ...exp, endDate: e.target.value };
                  onChange({ ...data, experience: newExp });
                }}
              />
            </div>
            <div className="space-y-2">
              {exp.highlights.map((highlight, hIndex) => (
                <div key={hIndex} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Achievement/Responsibility"
                    className="flex-1 p-2 border rounded"
                    value={highlight}
                    onChange={(e) => {
                      const newExp = [...data.experience];
                      newExp[index].highlights[hIndex] = e.target.value;
                      onChange({ ...data, experience: newExp });
                    }}
                  />
                  <button
                    onClick={() => {
                      const newExp = [...data.experience];
                      newExp[index].highlights = exp.highlights.filter(
                        (_, i) => i !== hIndex
                      );
                      onChange({ ...data, experience: newExp });
                    }}
                    className="p-2 text-red-500 hover:text-red-600"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
              <button
                onClick={() => {
                  const newExp = [...data.experience];
                  newExp[index].highlights.push('');
                  onChange({ ...data, experience: newExp });
                }}
                className="text-blue-500 hover:text-blue-600"
              >
                + Add Highlight
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Education</h2>
          <button
            onClick={addEducation}
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            <Plus size={16} /> Add Education
          </button>
        </div>
        {data.education.map((edu, index) => (
          <div key={edu.id} className="grid grid-cols-2 gap-4 p-4 border rounded">
            <input
              type="text"
              placeholder="Institution"
              className="p-2 border rounded"
              value={edu.institution}
              onChange={(e) => {
                const newEdu = [...data.education];
                newEdu[index] = { ...edu, institution: e.target.value };
                onChange({ ...data, education: newEdu });
              }}
            />
            <input
              type="text"
              placeholder="Degree"
              className="p-2 border rounded"
              value={edu.degree}
              onChange={(e) => {
                const newEdu = [...data.education];
                newEdu[index] = { ...edu, degree: e.target.value };
                onChange({ ...data, education: newEdu });
              }}
            />
            <input
              type="text"
              placeholder="Field of Study"
              className="p-2 border rounded"
              value={edu.field}
              onChange={(e) => {
                const newEdu = [...data.education];
                newEdu[index] = { ...edu, field: e.target.value };
                onChange({ ...data, education: newEdu });
              }}
            />
            <input
              type="text"
              placeholder="Graduation Date"
              className="p-2 border rounded"
              value={edu.graduationDate}
              onChange={(e) => {
                const newEdu = [...data.education];
                newEdu[index] = { ...edu, graduationDate: e.target.value };
                onChange({ ...data, education: newEdu });
              }}
            />
          </div>
        ))}
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Skills</h2>
        <textarea
          placeholder="Enter skills (comma-separated)"
          className="w-full p-2 border rounded h-32"
          value={data.skills.join(', ')}
          onChange={(e) =>
            onChange({
              ...data,
              skills: e.target.value.split(',').map((skill) => skill.trim()),
            })
          }
        />
      </div>
    </div>
  );
};