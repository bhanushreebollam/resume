import React from 'react';
import { ResumeData } from '../../types';

export const ModernTemplate: React.FC<{ data: ResumeData }> = ({ data }) => {
  return (
    <div className="w-full max-w-[800px] mx-auto p-8 bg-white shadow-lg">
      <div className="bg-blue-600 text-white p-8 -mx-8 -mt-8 mb-8">
        <h1 className="text-4xl font-bold mb-2 text-center">{data.personalInfo.name}</h1>
        <div className="text-blue-100 text-center">
          {data.personalInfo.email} • {data.personalInfo.phone} • {data.personalInfo.location}
        </div>
      </div>

      <div className="mb-8">
        <h2 className="text-2xl font-bold text-blue-600 mb-3">About Me</h2>
        <p className="text-gray-700 leading-relaxed">{data.personalInfo.summary}</p>
      </div>

      {data.experience.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-blue-600 mb-4">Experience</h2>
          {data.experience.map((exp) => (
            <div key={exp.id} className="mb-6">
              <div className="flex justify-between items-baseline">
                <h3 className="text-xl font-bold text-gray-800">{exp.company}</h3>
                <span className="text-blue-600 font-medium">
                  {exp.startDate} - {exp.endDate}
                </span>
              </div>
              <div className="text-lg text-gray-700 font-medium mb-2">{exp.position}</div>
              <ul className="list-disc list-inside space-y-1">
                {exp.highlights.map((highlight, index) => (
                  <li key={index} className="text-gray-600">
                    {highlight}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}

      {data.education.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-blue-600 mb-4">Education</h2>
          {data.education.map((edu) => (
            <div key={edu.id} className="mb-4">
              <div className="flex justify-between items-baseline">
                <h3 className="text-xl font-bold text-gray-800">{edu.institution}</h3>
                <span className="text-blue-600">{edu.graduationDate}</span>
              </div>
              <div className="text-gray-700 text-lg">
                {edu.degree} in {edu.field}
              </div>
            </div>
          ))}
        </div>
      )}

      {data.skills.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold text-blue-600 mb-4">Skills</h2>
          <div className="flex flex-wrap gap-2">
            {data.skills.map((skill, index) => (
              <span
                key={index}
                className="bg-blue-100 text-blue-700 px-4 py-2 rounded-full font-medium"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};