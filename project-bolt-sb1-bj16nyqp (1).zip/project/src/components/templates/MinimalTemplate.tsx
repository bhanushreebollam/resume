import React from 'react';
import { ResumeData } from '../../types';

export const MinimalTemplate: React.FC<{ data: ResumeData }> = ({ data }) => {
  return (
    <div className="w-full max-w-[800px] mx-auto p-8 bg-white shadow-lg">
      <div className="mb-8">
        <h1 className="text-4xl font-light mb-2">{data.personalInfo.name}</h1>
        <div className="text-gray-500 text-sm">
          {data.personalInfo.email} • {data.personalInfo.phone} • {data.personalInfo.location}
        </div>
      </div>

      <div className="mb-8">
        <p className="text-gray-700 leading-relaxed">{data.personalInfo.summary}</p>
      </div>

      {data.experience.length > 0 && (
        <div className="mb-8">
          <h2 className="text-sm uppercase tracking-wider text-gray-500 mb-4">Experience</h2>
          {data.experience.map((exp) => (
            <div key={exp.id} className="mb-6">
              <div className="flex justify-between items-baseline mb-1">
                <h3 className="text-lg font-medium">{exp.position}</h3>
                <span className="text-gray-500 text-sm">
                  {exp.startDate} - {exp.endDate}
                </span>
              </div>
              <div className="text-gray-600 text-sm mb-2">{exp.company}</div>
              <ul className="space-y-1">
                {exp.highlights.map((highlight, index) => (
                  <li key={index} className="text-gray-700 text-sm">
                    {highlight}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}

      {data.education.length > 0 && (
        <div className="mb-8">
          <h2 className="text-sm uppercase tracking-wider text-gray-500 mb-4">Education</h2>
          {data.education.map((edu) => (
            <div key={edu.id} className="mb-4">
              <div className="flex justify-between items-baseline">
                <div>
                  <h3 className="text-lg font-medium">{edu.degree}</h3>
                  <div className="text-gray-600 text-sm">
                    {edu.institution} • {edu.field}
                  </div>
                </div>
                <span className="text-gray-500 text-sm">{edu.graduationDate}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {data.skills.length > 0 && (
        <div>
          <h2 className="text-sm uppercase tracking-wider text-gray-500 mb-4">Skills</h2>
          <div className="flex flex-wrap gap-x-4 gap-y-2">
            {data.skills.map((skill, index) => (
              <span key={index} className="text-gray-700">
                {skill}
                {index < data.skills.length - 1 && "•"}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};