import React from 'react';
import { ResumeData } from '../../types';

export const ClassicTemplate: React.FC<{ data: ResumeData }> = ({ data }) => {
  return (
    <div className="w-full max-w-[800px] mx-auto p-8 bg-white shadow-lg">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-serif font-bold mb-2">{data.personalInfo.name}</h1>
        <div className="text-gray-600">
          {data.personalInfo.email} • {data.personalInfo.phone} • {data.personalInfo.location}
        </div>
      </div>

      <div className="mb-6">
        <h2 className="text-xl font-serif font-bold border-b-2 border-gray-300 mb-3">
          Professional Summary
        </h2>
        <p className="text-gray-700">{data.personalInfo.summary}</p>
      </div>

      {data.experience.length > 0 && (
        <div className="mb-6">
          <h2 className="text-xl font-serif font-bold border-b-2 border-gray-300 mb-3">
            Professional Experience
          </h2>
          {data.experience.map((exp) => (
            <div key={exp.id} className="mb-4">
              <div className="flex justify-between items-baseline">
                <h3 className="text-lg font-serif font-bold">{exp.company}</h3>
                <span className="text-gray-600 italic">
                  {exp.startDate} - {exp.endDate}
                </span>
              </div>
              <div className="text-gray-800 font-medium mb-2">{exp.position}</div>
              <ul className="list-disc list-inside">
                {exp.highlights.map((highlight, index) => (
                  <li key={index} className="text-gray-600 mb-1">
                    {highlight}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}

      {data.education.length > 0 && (
        <div className="mb-6">
          <h2 className="text-xl font-serif font-bold border-b-2 border-gray-300 mb-3">
            Education
          </h2>
          {data.education.map((edu) => (
            <div key={edu.id} className="mb-4">
              <div className="flex justify-between items-baseline">
                <h3 className="text-lg font-serif font-bold">{edu.institution}</h3>
                <span className="text-gray-600 italic">{edu.graduationDate}</span>
              </div>
              <div className="text-gray-800">
                {edu.degree} in {edu.field}
              </div>
            </div>
          ))}
        </div>
      )}

      {data.skills.length > 0 && (
        <div>
          <h2 className="text-xl font-serif font-bold border-b-2 border-gray-300 mb-3">
            Skills
          </h2>
          <div className="flex flex-wrap gap-2">
            {data.skills.map((skill, index) => (
              <span
                key={index}
                className="bg-gray-100 px-3 py-1 rounded text-gray-700"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};