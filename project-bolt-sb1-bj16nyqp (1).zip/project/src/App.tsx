import React, { useRef, useState } from 'react';
import { ResumeForm } from './components/ResumeForm';
import { ResumePreview } from './components/ResumePreview';
import { TemplateSelector } from './components/TemplateSelector';
import { ResumeData, TemplateType } from './types';
import { FileText, Printer } from 'lucide-react';
import { useReactToPrint } from 'react-to-print';

const initialData: ResumeData = {
  personalInfo: {
    name: '',
    email: '',
    phone: '',
    location: '',
    summary: '',
  },
  experience: [],
  education: [],
  skills: [],
};

function App() {
  const [resumeData, setResumeData] = useState<ResumeData>(initialData);
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>('edit');
  const [selectedTemplate, setSelectedTemplate] = useState<TemplateType>('modern');
  const previewRef = useRef<HTMLDivElement>(null);

  const handlePrint = useReactToPrint({
    content: () => previewRef.current,
  });

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <FileText className="text-blue-500" />
              Resume Builder
            </h1>
            <div className="flex gap-4">
              <button
                className={`px-4 py-2 rounded ${
                  activeTab === 'edit'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-700'
                }`}
                onClick={() => setActiveTab('edit')}
              >
                Edit
              </button>
              <button
                className={`px-4 py-2 rounded ${
                  activeTab === 'preview'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-700'
                }`}
                onClick={() => setActiveTab('preview')}
              >
                Preview
              </button>
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
              >
                <Printer size={16} />
                Print/Save PDF
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <TemplateSelector
          selectedTemplate={selectedTemplate}
          onSelect={setSelectedTemplate}
        />
        
        {activeTab === 'edit' ? (
          <ResumeForm data={resumeData} onChange={setResumeData} />
        ) : (
          <div ref={previewRef}>
            <ResumePreview data={resumeData} template={selectedTemplate} />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;