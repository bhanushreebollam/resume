from flask import Flask, render_template, request, jsonify, send_file
from datetime import datetime
import json
import os

app = Flask(__name__)

class Resume:
    def __init__(self):
        self.data = {
            "personal_info": {
                "name": "",
                "email": "",
                "phone": "",
                "location": "",
                "summary": ""
            },
            "experience": [],
            "education": [],
            "skills": []
        }

    def update(self, data):
        self.data.update(data)

    def to_dict(self):
        return self.data

# Global resume instance
resume = Resume()

@app.route('/')
def index():
    return render_template('index.html', resume=resume.data)

@app.route('/preview/<template>')
def preview(template):
    template_file = f'preview_{template}.html'
    return render_template(template_file, resume=resume.data)

@app.route('/update', methods=['POST'])
def update_resume():
    data = request.get_json()
    resume.update(data)
    return jsonify({"status": "success"})

@app.route('/add_experience', methods=['POST'])
def add_experience():
    experience = {
        "id": str(datetime.now().timestamp()),
        "company": "",
        "position": "",
        "start_date": "",
        "end_date": "",
        "highlights": [""]
    }
    resume.data["experience"].append(experience)
    return jsonify(experience)

@app.route('/add_education', methods=['POST'])
def add_education():
    education = {
        "id": str(datetime.now().timestamp()),
        "institution": "",
        "degree": "",
        "field": "",
        "graduation_date": ""
    }
    resume.data["education"].append(education)
    return jsonify(education)

if __name__ == '__main__':
    app.run(debug=True)